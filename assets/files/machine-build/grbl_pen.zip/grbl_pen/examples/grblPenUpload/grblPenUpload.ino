/*
  grblPenUpload.ino - firmware of the AA 598 class pen plotter ("drawing machine")

  Uploading this sketch puts grbl_pen on an Arduino Uno. grbl_pen is Grbl 1.1h
  (a g-code interpreter) with a servo pen lift on pin D11, homing with the X and Y
  limit switches, and the plotter's settings built in. What exactly was changed is
  written in README.md in the grbl_pen library folder.

  How to upload:
    1. Tools > Board > Arduino Uno
    2. Tools > Port > the port of your Uno
    3. Sketch > Upload
  There is nothing to edit. Do not add any code to this sketch.

  How to check: open Tools > Serial Monitor, set 115200 baud. The Uno answers

    Grbl 1.1h ['$' for help]
    [MSG:grbl_pen: M5=pen up, M3 S70=pen down, $H=home]
    [MSG:'$H'|'$X' to unlock]

  The second line tells you that this firmware (not the original Grbl) is on the
  board. Close the Serial Monitor before you connect a g-code sender.

  Grbl is free software, released under the GNU General Public License version 3
  (see the file COPYING in the library folder). Grbl is Copyright (c) 2009-2011
  Simen Svale Skogsrud and Copyright (c) 2011-2016 Sungeun K. Jeon for Gnea
  Research LLC. Modified 2026-11-16 for the AA 598 pen plotter.
*/

#include <grbl_pen.h>

// Do not alter this file!
