# grbl_pen

Firmware for the AA 598 class pen plotter ("drawing machine"): **Grbl 1.1h** for the Arduino Uno
with a servo pen lift, homing on two limit switches, and the plotter's settings built in.

Modified 2026-11-16 from Grbl 1.1h (build 20190830, https://github.com/gnea/grbl).
Every changed block in the source is marked with a comment that starts with `// PEN:`.

## Install and upload

1. Arduino IDE: **Sketch → Include Library → Add .ZIP Library…** and pick `grbl_pen.zip`.
2. **File → Examples → grbl_pen → grblPenUpload**.
3. **Tools → Board → Arduino Uno**, pick the port, **Upload**. Nothing to edit.
4. Serial Monitor at **115200 baud** shows:

```
Grbl 1.1h ['$' for help]
[MSG:grbl_pen: M5=pen up, M3 S70=pen down, $H=home]
[MSG:'$H'|'$X' to unlock]
```

The second line is how you see that this firmware is on the board. The library can stay installed
next to the original `grbl` library: the sketch includes `grbl_pen.h`, which only this library has.

On the first start after the upload the firmware resets the EEPROM (settings, work offsets,
startup lines) to the plotter defaults, also on a board that ran the original Grbl or an older
grbl_pen (work area 340 × 190 or 310 × 290 mm) before. That
one time it prints `error:7` and the settings list in front of the welcome lines, and the start
takes about 0.8 s longer. If the board is reset during that time (the Arduino IDE does this when
it opens the Serial Monitor), the next start simply does it again.

## Pins (fixed)

| Uno pin | Use |
|---|---|
| D2, D5 | X stepper driver STEP, DIR |
| D3, D6 | Y stepper driver STEP, DIR |
| D8 | EN of both drivers (LOW = motors on) |
| D9 | X limit switch (normally closed to GND) |
| D10 | Y limit switch (normally closed to GND) |
| D11 | Servo signal |
| A0, A1, A2 | Grbl's reset / feed hold / cycle start inputs: leave empty |
| D4, D7, D12, D13, A3, A4, A5 | not used by the plotter. Leave empty (Grbl still drives D4, D7, D13, A3 as outputs) |

## Commands

| Command | What it does |
|---|---|
| `$H` | Home: both axes run to their limit switches and back off 3 mm. That point is X0 Y0. Homing lifts the pen. |
| `$X` | Unlock without homing (the firmware is locked, "Alarm", after every power-up). |
| `M5` | Pen up: servo to the pen-up angle `$31` (30). Also after power-up, reset, alarm, `$H`, `M2`/`M30`. |
| `M3 S70` | Pen down: servo to 70 degrees. `M3 S50` = position for loading a pen. |
| `G4 P0.2` | Wait 0.2 s. Put it after every pen command (the servo needs time). |
| `G0 X.. Y..` / `G1 X.. Y.. F2400` | Move fast / draw at 2400 mm/min. X 0 … 260 mm, Y 0 … 240 mm. |
| `?` `!` `~` Ctrl-X | Status, feed hold, resume, reset (as in Grbl). |

Servo angles use the scale of Arduino's `Servo.write()`: 0 degrees = 544 µs pulse, 180 degrees =
2400 µs. The pulse is repeated every 16.4 ms (61 Hz) and is never switched off. It changes in steps
of 64 µs (about 6 degrees).

`M3 S<angle>` never moves the servo beyond the pen-up angle and at most 90 degrees away from it:
with `$31=30` the range is 30 … 120. If the servo is mounted so that it turns the other way, set
`$31=150` and use `M3 S110` for pen down (range 60 … 150). `M4` does the same as `M3`.

## Settings that differ from the original Grbl

| Setting | Value | Meaning |
|---|---|---|
| `$1` | 255 | motors stay energised |
| `$5` | 1 | limit switches are normally closed (pin HIGH = pressed, or wire off) |
| `$20`, `$21`, `$22` | 1, 0, 1 | soft limits on, hard limits off, homing on |
| `$23` | 3 | home toward −X and −Y |
| `$24`, `$25`, `$26`, `$27` | 150, 1500, 250, 3 | homing: slow / fast feed (mm/min), debounce (ms), pull-off (mm) |
| `$30` | 180 | not used |
| `$31` | 30 | **pen-up angle of the servo** (original Grbl: minimum spindle speed) |
| `$32` | 0 | laser mode: leave it at 0 |
| `$100`, `$101` | 40 | steps/mm (GT2 belt, 20-tooth pulley, 1/8 step) |
| `$110`, `$111` | 6000 | maximum speed, mm/min |
| `$120`, `$121` | 200 | acceleration, mm/s² |
| `$130`, `$131` | 260, 240 | travel = soft-limit area, mm |
| `$3` | 0 | set 1 (X), 2 (Y) or 3 (both) if an axis runs the wrong way |

The remaining values: `$0=10 $2=0 $4=0 $6=0 $10=1 $11=0.010 $12=0.002 $13=0 $102=40 $112=6000
$122=200 $132=10`. `$RST=$` brings all of them back.

## What was changed in the source

| File | Change |
|---|---|
| `spindle_control.c`, `cpu_map.h` | Timer2 runs a 61 Hz servo signal on D11 that is never switched off. "Spindle off" loads the pen-up pulse; `S` is an angle, limited as described above. The spindle speed override is ignored. |
| `config.h` | `DEFAULTS_PEN_PLOTTER`; one homing cycle for X and Y together; `HOMING_FORCE_SET_ORIGIN` (home = X0 Y0, all coordinates positive). |
| `cpu_map.h` | Only D9 and D10 are limit inputs. D12 (Z limit in the original) is not read. |
| `defaults.h` | The `DEFAULTS_PEN_PLOTTER` block. |
| `settings.h` | `SETTINGS_VERSION` 113, so that an EEPROM written by the original Grbl or by an older grbl_pen (version 111: work area 340 × 190 mm, 112: 310 × 290 mm) is replaced. |
| `settings.c` | `$31` moves the servo at once; `$30` is only stored. A settings reset clears the stored startup lines and build info completely (the original leaves two records that it later reports as `error:7`). It marks the stored settings as not valid first and writes them, with the version byte, last. If the board is reset in the middle, the next start repeats it. With the original order a half-finished reset is accepted as valid, because the checksum only covers the last bytes: mixed old and new settings, old work offsets and old startup lines would stay. |
| `motion_control.c` | After `$H` the g-code state is `M5`, because the homing moves lift the pen (the original leaves it at `M3`, and the next `M3 S70` is then skipped as "no change"). |
| `report.c` | The extra `[MSG:grbl_pen: …]` line after the welcome line. The welcome line itself is unchanged. |
| `eeprom.c` | While a byte is being stored, interrupts stay on. The original switches them off for 1.8 to 3.4 ms per byte, and characters that a sender transmits meanwhile are lost (for example after `G10 L2 …` with new values). |
| `grbl.h` | Compile-time check that the build options fit the servo code. |
| `grbl_pen.h`, `examples/grblPenUpload` | New. The original examples were removed. |

## Good to know

- After power-up and after every alarm the firmware is locked: send `$H` (or `$X`).
- There is no Z motor. A g-code file with `Z` moves above 0 stops with `ALARM:2`
  (Z is limited to −10 … 0 like the other axes are limited to their travel).
- Feed hold (`!`) does not lift the pen. Reset (Ctrl-X) does.
- G-code files must be plain ASCII without `!`, `~` or `?`, also in comments. Grbl executes these
  characters, and every byte above 0x7F, as commands the moment they arrive: `!` stops the plot
  (feed hold), and for example the UTF-8 code of `×` contains 0x97 = "rapid moves at 25 %".
- A target outside the work area stops the plot with `ALARM:2` as soon as the firmware reads that
  line, which is before the machine gets there: the move in progress is cut short and the pen lifts.
- `ALARM:9` after `$H` = a limit switch was not found within 390 mm; `ALARM:8` = a switch still
  reads "pressed" after the pull-off (wire off?). `ALARM:2` = target outside the work area.
- Laser mode (`$32=1`) was left as in the original and makes no sense with a servo.
- Size: 29 702 bytes of 32 256 flash, 1 639 bytes of 2 048 RAM used by variables.

## Licence

Grbl is free software, released under the GNU General Public License version 3 (file `COPYING`).
Copyright (c) 2009-2011 Simen Svale Skogsrud, Copyright (c) 2011-2016 Sungeun K. Jeon for Gnea
Research LLC. `eeprom.c` is based on Atmel application note AVR103. The changes for the pen plotter
are released under the same licence.
