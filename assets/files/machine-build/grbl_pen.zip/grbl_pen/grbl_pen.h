/*
  grbl_pen.h - the one header a sketch includes to get the pen-plotter firmware
  Part of grbl_pen: Grbl 1.1h modified for the AA 598 pen plotter (2026-11-16).

  This file only exists to give the library a name of its own: a sketch that says
  #include <grbl_pen.h> always gets this library, also when the original "grbl"
  library is installed next to it. Everything else is in grbl.h.

  Grbl is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Grbl is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Grbl.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef grbl_pen_h
#define grbl_pen_h

#include "grbl.h"

#endif
