/*
  JoystickDraw: drive the AA598 drawing machine with a joystick (no GRBL needed).

  How to use it
    1. Upload this sketch. Open the Serial Monitor at 115200 baud (optional).
    2. Click the joystick: the machine homes. The arm pulls in until the Y switch clicks,
       then the carriage moves to the X motor end until the X switch clicks.
       Home (X0 Y0) is 3 mm back from each click.
    3. Push the stick: the pen moves. The further you push, the faster (up to 40 mm/s).
       It never leaves the 260 x 240 mm work area.
    4. Click the joystick: pen down / pen up. The pen stops for 0.2 s while the servo moves.
    5. Hold the joystick pressed for 1.5 s: the machine redraws everything you drew since
       homing (put a fresh sheet in first). Click to stop it.
    The Serial Monitor shows every move as G-code. Lines starting with ";" are comments, so
    you can save the whole output as a .gcode file and draw it again with the GRBL firmware.
    Serial keys (handy without a joystick): h home, d pen down, u pen up, r redraw,
    c clear the recording, ? status.

  Wiring: the same as for the GRBL firmware (grbl_pen), plus the joystick on A4, A5 and D12.
  GRBL does not use those three pins, so the joystick can stay plugged in for both programs.
*/

// ---------- pins ----------
const uint8_t X_STEP_PIN = 2;
const uint8_t Y_STEP_PIN = 3;
const uint8_t X_DIR_PIN = 5;
const uint8_t Y_DIR_PIN = 6;
const uint8_t ENABLE_PIN = 8;       // EN of both drivers: LOW = motors on
const uint8_t X_LIMIT_PIN = 9;      // switch terminal 1 to GND, terminal 2 to the pin
const uint8_t Y_LIMIT_PIN = 10;
const uint8_t SERVO_PIN = 11;       // pen servo signal (must be pin 11: hardware PWM)
const uint8_t JOY_BUTTON_PIN = 12;  // joystick SW
const uint8_t JOY_X_PIN = A4;       // joystick VRx
const uint8_t JOY_Y_PIN = A5;       // joystick VRy
const uint8_t LED_PIN = 13;         // on-board LED: on = homed, blinking = error

// ---------- settings (the same numbers as the GRBL firmware) ----------
const float STEPS_PER_MM = 40.0;    // 200 steps x 8 microsteps / (20 teeth x 2 mm)
const float X_MAX_MM = 260.0;       // work area, measured from home
const float Y_MAX_MM = 240.0;
const float X_SEARCH_MM = 330.0;    // homing: farthest it looks for a switch. Longer than the whole rod
const float Y_SEARCH_MM = 310.0;    // travel (not the work area), so homing works from anywhere
const float MAX_SPEED = 40.0;       // mm/s with the stick pushed all the way
const float ACCEL = 200.0;          // mm/s^2
const float DRAW_SPEED = 40.0;      // mm/s when redrawing with the pen down
const float TRAVEL_SPEED = 60.0;    // mm/s when redrawing with the pen up
const float HOME_FAST = 25.0;       // mm/s, first search for a switch
const float HOME_SLOW = 2.5;        // mm/s, second, precise touch
const float PULL_OFF = 3.0;         // mm: home is this far back from the click
const bool FLIP_X = false;          // Home drives the carriage AWAY from the X motor? set true
const bool FLIP_Y = false;          // Home pushes the arm OUT? set true
const bool STICK_FLIP_X = false;    // stick right moves the pen left? set true
const bool STICK_FLIP_Y = false;    // stick forward pulls the arm in? set true
const int PEN_UP_ANGLE = 30;        // servo angle for pen up   (GRBL: M5)
const int PEN_DOWN_ANGLE = 70;      // servo angle for pen down (GRBL: M3 S70)
const int DEAD_ZONE = 40;           // joystick counts around the centre that mean "stop"
const int MAX_POINTS = 300;         // corners the recording can hold
const float TOLERANCE = 0.5;        // mm: the redrawn path stays this close to yours

// ---------- one motor axis ----------
struct Axis {
  uint8_t stepPin, dirPin, limitPin;
  bool flip;
  long maxSteps;            // end of the work area, in steps from home
  long pos;                 // steps from home
  int8_t dir;               // direction the DIR pin is set for (+1 / -1)
  float speed;              // mm/s, signed (joystick mode)
  unsigned long interval;   // microseconds between steps at that speed (0 = stopped)
  unsigned long last;       // micros() of the last step
};
Axis ax = {X_STEP_PIN, X_DIR_PIN, X_LIMIT_PIN, FLIP_X, (long)(X_MAX_MM * STEPS_PER_MM), 0, 0, 0, 0, 0};
Axis ay = {Y_STEP_PIN, Y_DIR_PIN, Y_LIMIT_PIN, FLIP_Y, (long)(Y_MAX_MM * STEPS_PER_MM), 0, 0, 0, 0, 0};

bool homed = false, penDown = false, stickOk = false, errorBlink = false;
unsigned long penMovedAt = 0;       // millis() of the last pen change
int centreX = 512, centreY = 512;

// ---------- the recording: points in 0.1 mm; bit 15 of x = pen down on the way TO the point ----------
struct Point { uint16_t x, y; };
Point pts[MAX_POINTS];
int nPts = 0;
float startX = 0, startY = 0;  // where the recording starts (home, or where it was cleared)
float ancX, ancY;            // last recorded point (mm)
float dirX, dirY;            // direction of the current straight stretch
bool haveDir = false;
float maxAlong, farX, farY, prevX, prevY;
bool wasMoving = false;

// ================= low level =================
float mm(const Axis &a) { return a.pos / STEPS_PER_MM; }

// NC wiring: not pressed = pin joined to GND (LOW); pressed or a loose wire = HIGH
bool switchPressed(const Axis &a) { return digitalRead(a.limitPin) == HIGH; }

bool buttonDown() { return digitalRead(JOY_BUTTON_PIN) == LOW; }

void setDir(Axis &a, int8_t d) {
  if (d == a.dir) return;
  // like GRBL with $3=0: DIR HIGH = toward home (negative)
  digitalWrite(a.dirPin, ((d < 0) != a.flip) ? HIGH : LOW);
  a.dir = d;
  delayMicroseconds(5);
}

void pulse(Axis &a) {
  digitalWrite(a.stepPin, HIGH);
  delayMicroseconds(3);
  digitalWrite(a.stepPin, LOW);
  a.pos += a.dir;
}

// Pen servo on pin 11 with Timer2's hardware PWM: 61 Hz, 64 us steps, the same pulses as grbl_pen.
void servoInit() {
  pinMode(SERVO_PIN, OUTPUT);
  TCCR2A = _BV(COM2A1) | _BV(WGM21) | _BV(WGM20);   // fast PWM on OC2A (pin 11)
  TCCR2B = _BV(CS22) | _BV(CS21) | _BV(CS20);       // clock / 1024
}

void setPen(bool down) {
  int angle = down ? PEN_DOWN_ANGLE : PEN_UP_ANGLE;
  float us = 544 + angle * (2400.0 - 544.0) / 180.0;   // same angle scale as the Servo library
  OCR2A = (uint8_t)(lround(us / 64.0) - 1);            // pulse = (OCR2A + 1) x 64 us
  penDown = down;
}

void msg(const __FlashStringHelper *s) { Serial.print(F("; ")); Serial.println(s); }

// ================= the recording =================
void startRecording(float x, float y) {
  ancX = prevX = x; ancY = prevY = y; haveDir = false; wasMoving = false;
}

void clearRecording() {      // a new, empty recording that starts where the pen is now
  nPts = 0; startX = mm(ax); startY = mm(ay);
  startRecording(startX, startY);
}

void printXY(float x, float y) {
  Serial.print(F(" X")); Serial.print(x, 2);
  Serial.print(F(" Y")); Serial.println(y, 2);
}

// store the end of a stretch drawn with the current pen state, and print it as G-code
void recordPoint(float x, float y) {
  Serial.print(penDown ? F("G1") : F("G0"));
  printXY(x, y);
  if (nPts < MAX_POINTS) {
    pts[nPts].x = (uint16_t)lround(x * 10) | (penDown ? 0x8000 : 0);
    pts[nPts].y = (uint16_t)lround(y * 10);
    nPts++;
    if (nPts == MAX_POINTS) msg(F("recording full: hold the button to redraw, or reset to start over"));
  }
  startRecording(x, y);
}

// called every 10 ms while moving: keep one point per corner (path error <= TOLERANCE)
void trackPath(float x, float y) {
  if (!penDown) return;      // pen up: the way does not matter, only where it stops
  float ex = x - ancX, ey = y - ancY;
  if (!haveDir) {
    float d = sqrt(ex * ex + ey * ey);
    if (d >= 1.0) { dirX = ex / d; dirY = ey / d; haveDir = true; maxAlong = d; farX = x; farY = y; }
  } else {
    float along = ex * dirX + ey * dirY;
    float side = fabs(ex * dirY - ey * dirX);
    // turned a corner (half the tolerance: the straight line to prevX/prevY can be off by the other half)
    if (side > TOLERANCE / 2) { recordPoint(prevX, prevY); trackPath(x, y); return; }
    if (along < maxAlong - TOLERANCE) { recordPoint(farX, farY); trackPath(x, y); return; }   // came back
    if (along > maxAlong) { maxAlong = along; farX = x; farY = y; }
  }
  prevX = x; prevY = y;
}

// store where the pen is now, unless that is the last stored point already
void endStretch() {
  float x = mm(ax), y = mm(ay);
  if (fabs(x - ancX) > 0.05 || fabs(y - ancY) > 0.05) recordPoint(x, y);
}

void stopStick() { ax.speed = ay.speed = 0; ax.interval = ay.interval = 0; }

void togglePen() {
  stopStick();               // the pen goes down / up exactly here, as in the redraw
  endStretch();
  setPen(!penDown);
  Serial.println(penDown ? F("M3 S70") : F("M5"));
  Serial.println(F("G4 P0.2"));
  penMovedAt = millis();     // the stick waits 0.2 s for the pen, like G4 P0.2
}

// ================= moves used by homing and redrawing =================
// One axis at constant speed. Stops when the switch becomes pressed (until = 1) or released (until = 0);
// until = -1 never stops early. Returns the distance moved in mm, -1 if the switch never changed,
// -2 if the joystick button stopped it.
float jog(Axis &a, int8_t d, float speed, float maxMm, int8_t until) {
  setDir(a, d);
  unsigned long interval = (unsigned long)(1e6 / (speed * STEPS_PER_MM));
  long n = (long)(maxMm * STEPS_PER_MM);
  unsigned long t = micros();
  for (long i = 0; i <= n; i++) {
    if (until >= 0 && switchPressed(a) == (until == 1)) return i / STEPS_PER_MM;
    if (i == n) break;
    if (buttonDown()) return -2;
    while (micros() - t < interval) { }
    t += interval;
    pulse(a);
  }
  return until < 0 ? maxMm : -1;
}

// Straight line to (x, y) in mm with both motors in step and a gentle start and stop.
// Returns false if the joystick button stopped it.
bool lineTo(float x, float y, float vmax) {
  long tx = constrain(lround(x * STEPS_PER_MM), 0L, ax.maxSteps);
  long ty = constrain(lround(y * STEPS_PER_MM), 0L, ay.maxSteps);
  long dx = tx - ax.pos, dy = ty - ay.pos;
  setDir(ax, dx >= 0 ? 1 : -1);
  setDir(ay, dy >= 0 ? 1 : -1);
  dx = labs(dx); dy = labs(dy);
  long n = max(dx, dy);
  if (n == 0) return true;
  float ds = sqrt((float)dx * dx + (float)dy * dy) / STEPS_PER_MM / n;   // mm of path per step of the longer axis
  long ex = n / 2, ey = n / 2;
  unsigned long t = micros();
  for (long i = 0; i < n; i++) {
    float v = min(vmax, min(sqrt(25.0 + 2 * ACCEL * i * ds), sqrt(25.0 + 2 * ACCEL * (n - i) * ds)));
    unsigned long interval = (unsigned long)(ds / v * 1e6);
    while (micros() - t < interval) { if (buttonDown()) return false; }
    t += interval;
    ex += dx; if (ex >= n) { ex -= n; pulse(ax); }
    ey += dy; if (ey >= n) { ey -= n; pulse(ay); }
  }
  return true;
}

// The pen needs 0.3 s to move. Returns false if the joystick button was pressed meanwhile.
bool penWait() {
  unsigned long t = millis();
  while (millis() - t < 300) { if (buttonDown()) return false; }
  return true;
}

// Wait until the joystick button is let go. A SW wire on GND looks like a button that is never let go.
void waitForRelease() {
  unsigned long t = millis();
  bool told = false;
  while (buttonDown()) {
    if (!told && millis() - t > 3000) { msg(F("Waiting for the joystick button to be let go. If it is not pressed, check the SW wire on D12.")); told = true; }
  }
}

// ================= homing =================
bool fail(char axis, const __FlashStringHelper *why) {
  setPen(false);
  homed = false; errorBlink = true;
  Serial.print(F("; ERROR ")); Serial.print(axis); Serial.print(F(": ")); Serial.println(why);
  msg(F("Fix it, then click the joystick (or send h) to home again."));
  waitForRelease();                                         // a stop click must not start homing again
  return false;
}

bool homeAxis(Axis &a, float search, char name) {
  float r;
  if (switchPressed(a)) {                                   // already on the switch: move off it first
    r = jog(a, +1, 10, 10, 0);
    if (r == -2) return fail(name, F("stopped by the button"));
    if (r < 0) return fail(name, F("switch reads pressed all the time: check terminal 1 to GND, terminal 2 to the pin"));
    if (jog(a, +1, 10, 2, -1) == -2) return fail(name, F("stopped by the button"));
  }
  r = jog(a, -1, HOME_FAST, search, 1);                    // search
  if (r == -2) return fail(name, F("stopped by the button"));
  if (r < 0) return fail(name, F("never reached its switch: wrong direction (change FLIP), switch not wired, or no 12V"));
  r = jog(a, +1, 10, 10, 0);                                // back off until it releases
  if (r == -2) return fail(name, F("stopped by the button"));
  if (r < 0) return fail(name, F("switch did not release: check its wires"));
  if (jog(a, +1, 10, 1, -1) == -2) return fail(name, F("stopped by the button"));
  r = jog(a, -1, HOME_SLOW, 6, 1);                          // slow, precise touch
  if (r == -2) return fail(name, F("stopped by the button"));
  if (r < 0) return fail(name, F("lost the switch on the slow touch"));
  r = jog(a, +1, 10, PULL_OFF, -1);                         // pull off: this is home
  if (r == -2) return fail(name, F("stopped by the button"));
  if (switchPressed(a)) return fail(name, F("switch still pressed 3 mm after the click"));
  a.pos = 0;
  return true;
}

void homeAll() {
  stopStick();
  setPen(false);
  errorBlink = false;
  msg(F("Homing: arm in (Y), then carriage to the X motor (X). Click to stop."));
  waitForRelease();                                         // let go of the button first
  delay(300);                                               // pen up before moving
  if (!homeAxis(ay, Y_SEARCH_MM, 'Y')) return;
  if (!homeAxis(ax, X_SEARCH_MM, 'X')) return;
  homed = true;
  digitalWrite(LED_PIN, HIGH);
  clearRecording();
  msg(F("Homed: this corner is X0 Y0. Drive with the stick, click for pen down/up."));
  Serial.println(F("G21 G90 G54\nG92.1\nG10 L2 P1 X0 Y0\nM5\nG4 P0.2\nG0 X0 Y0\nF2400"));
}

// ================= redraw the recording =================
void redraw() {
  stopStick();
  endStretch();
  if (nPts == 0) { msg(F("Nothing recorded yet.")); return; }
  if (penDown) togglePen();                                 // pen up, also in the printed G-code (M5)
  waitForRelease();                                         // let go of the button first
  Serial.print(F("; Redrawing ")); Serial.print(nPts); Serial.println(F(" points. Click to stop."));
  setPen(false); delay(300);                                // (the released button may still bounce)
  bool ok = lineTo(startX, startY, TRAVEL_SPEED);           // pen up to where the recording starts
  for (int i = 0; i < nPts && ok; i++) {
    bool p = pts[i].x & 0x8000;
    if (p != penDown) { setPen(p); ok = penWait(); }
    ok = ok && lineTo((pts[i].x & 0x7FFF) / 10.0, pts[i].y / 10.0, p ? DRAW_SPEED : TRAVEL_SPEED);
  }
  setPen(false); delay(300);
  if (ok) ok = lineTo(0, 0, TRAVEL_SPEED);                  // back home
  endStretch();                                             // your drawing goes on from here (pen up)
  if (ok) msg(F("Redraw done. Back at home."));
  else { msg(F("Redraw stopped.")); waitForRelease(); }
  ax.last = ay.last = micros();
}

// ================= joystick mode =================
float stickSpeed(int raw, int centre, bool flip) {
  int d = raw - centre;
  if (abs(d) <= DEAD_ZONE) return 0;
  int range = (d > 0 ? 1023 - centre : centre) - DEAD_ZONE;   // counts from the dead zone to the end of the stick
  float s = (abs(d) - DEAD_ZONE) / (float)range;
  if (s > 1) s = 1;
  float v = MAX_SPEED * s * s;                             // gentle near the centre for fine work
  if (d < 0) v = -v;
  return flip ? -v : v;
}

// change the speed toward the target, and slow down in time for the edge of the work area
void rampTo(Axis &a, float target, float dt) {
  float room = target > 0 ? (a.maxSteps - a.pos) / STEPS_PER_MM : a.pos / STEPS_PER_MM;
  if (room < 0) room = 0;
  float vEdge = sqrt(2 * ACCEL * room);
  if (target > vEdge) target = vEdge;
  if (target < -vEdge) target = -vEdge;
  float dv = ACCEL * dt;
  if (target > a.speed + dv) a.speed += dv;
  else if (target < a.speed - dv) a.speed -= dv;
  else a.speed = target;
  a.interval = (a.speed == 0) ? 0 : (unsigned long)(1e6 / (fabs(a.speed) * STEPS_PER_MM));
}

// one step if it is time for it; never leaves the work area
void runAxis(Axis &a, unsigned long now) {
  if (a.interval == 0) return;
  int8_t d = a.speed > 0 ? 1 : -1;
  if ((d > 0 && a.pos >= a.maxSteps) || (d < 0 && a.pos <= 0)) return;
  if (now - a.last >= a.interval) {
    setDir(a, d);
    pulse(a);
    a.last = (now - a.last >= 2 * a.interval) ? now : a.last + a.interval;
  }
}

// debounced button: returns 1 for a click (released within 1.5 s), 2 when held for 1.5 s
uint8_t buttonEvent() {
  static uint8_t same = 0;
  static bool raw = false, state = false, holdSent = false;
  static unsigned long since = 0;
  bool now = buttonDown();
  if (now == raw) { if (same < 3) same++; } else { raw = now; same = 0; }
  if (same < 3 || raw == state) {                           // no stable change
    if (state && !holdSent && millis() - since >= 1500) { holdSent = true; return 2; }
    return 0;
  }
  state = raw;
  if (state) { since = millis(); holdSent = false; return 0; }
  return holdSent ? 0 : 1;                                  // released
}

void status() {
  Serial.print(F("; homed ")); Serial.print(homed ? F("yes") : F("no"));
  Serial.print(F(", X ")); Serial.print(mm(ax), 2); Serial.print(F(" Y ")); Serial.print(mm(ay), 2);
  Serial.print(F(", pen ")); Serial.print(penDown ? F("down") : F("up"));
  Serial.print(F(", switches X ")); Serial.print(switchPressed(ax) ? F("pressed") : F("free"));
  Serial.print(F(" Y ")); Serial.print(switchPressed(ay) ? F("pressed") : F("free"));
  Serial.print(F(", stick ")); Serial.print(analogRead(JOY_X_PIN)); Serial.print(' '); Serial.print(analogRead(JOY_Y_PIN));
  Serial.print(F(", points ")); Serial.println(nPts);
}

void tick() {                                                // every 10 ms
  uint8_t ev = buttonEvent();
  if (!homed) {
    if (ev) homeAll();
    if (errorBlink) digitalWrite(LED_PIN, (millis() / 250) % 2);
    return;
  }
  if (ev == 1) togglePen();
  if (ev == 2) { redraw(); return; }
  if (!stickOk || millis() - penMovedAt < 200) return;
  rampTo(ax, stickSpeed(analogRead(JOY_X_PIN), centreX, STICK_FLIP_X), 0.01);
  rampTo(ay, stickSpeed(analogRead(JOY_Y_PIN), centreY, STICK_FLIP_Y), 0.01);
  bool moving = ax.speed != 0 || ay.speed != 0;
  float x = mm(ax), y = mm(ay);
  if (moving) trackPath(x, y);
  else if (wasMoving && (fabs(x - ancX) > 0.1 || fabs(y - ancY) > 0.1)) recordPoint(x, y);   // stopped: end of stretch
  wasMoving = moving;
}

void serialKey(char c) {
  switch (c) {
    case 'h': homeAll(); break;
    case 'd': if (homed && !penDown) togglePen(); break;
    case 'u': if (homed && penDown) togglePen(); break;
    case 'r': if (homed) redraw(); break;
    case 'c': clearRecording(); msg(F("Recording cleared.")); break;
    case '?': status(); break;
  }
}

// ================= setup and loop =================
void setup() {
  pinMode(X_STEP_PIN, OUTPUT); pinMode(Y_STEP_PIN, OUTPUT);
  pinMode(X_DIR_PIN, OUTPUT); pinMode(Y_DIR_PIN, OUTPUT);
  pinMode(ENABLE_PIN, OUTPUT); digitalWrite(ENABLE_PIN, LOW);      // motors on (they hold their position)
  pinMode(X_LIMIT_PIN, INPUT_PULLUP); pinMode(Y_LIMIT_PIN, INPUT_PULLUP);
  pinMode(JOY_BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  servoInit();
  setPen(false);
  Serial.begin(115200);
  msg(F("JoystickDraw for the AA598 drawing machine"));
  long sx = 0, sy = 0;                                         // the stick's resting position
  for (int i = 0; i < 16; i++) { sx += analogRead(JOY_X_PIN); sy += analogRead(JOY_Y_PIN); delay(2); }
  centreX = sx / 16; centreY = sy / 16;
  stickOk = abs(centreX - 512) < 100 && abs(centreY - 512) < 100;
  // a pin with no wire on it can read anything, also 512; with its pull-up switched on it reads 1023
  pinMode(JOY_X_PIN, INPUT_PULLUP); pinMode(JOY_Y_PIN, INPUT_PULLUP);
  delay(2);
  if (analogRead(JOY_X_PIN) > 1000 || analogRead(JOY_Y_PIN) > 1000) stickOk = false;
  pinMode(JOY_X_PIN, INPUT); pinMode(JOY_Y_PIN, INPUT);
  if (!stickOk) msg(F("Joystick not centred or not connected (A4, A5): the stick is ignored. Fix it and press reset."));
  msg(F("Click the joystick (or send h) to home."));
}

void loop() {
  static unsigned long lastTick = 0;
  if (homed) {
    unsigned long now = micros();
    runAxis(ax, now);
    runAxis(ay, now);
  }
  if (millis() - lastTick >= 10) {
    lastTick = (millis() - lastTick > 50) ? millis() : lastTick + 10;   // after homing or a redraw: no catch-up burst
    tick();
  }
  if (Serial.available()) serialKey(Serial.read());
}
